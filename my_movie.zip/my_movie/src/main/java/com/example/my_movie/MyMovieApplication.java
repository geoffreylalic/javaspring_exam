package com.example.my_movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMovieApplication.class, args);
	}

}
