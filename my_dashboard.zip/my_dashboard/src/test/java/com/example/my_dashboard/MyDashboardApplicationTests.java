package com.example.my_dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
